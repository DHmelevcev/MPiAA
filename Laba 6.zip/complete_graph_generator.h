#pragma once

#include <vector>
#include <algorithm>

std::vector<std::pair<std::pair<int, int>, double>> generate_complete_graph_edges(int vertices_size, double max_weight);