#pragma once

#include <vector>

std::vector<int> count_sort(const std::vector<int>& array, int min, int max);