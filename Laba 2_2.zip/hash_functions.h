#pragma once

#include <string>
#include <functional>
#include <vector>

std::size_t hash1(const std::string& key);

std::size_t hash2(const std::string& key);

std::size_t hash3(const std::string& key);